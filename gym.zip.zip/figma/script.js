let slideIndex = 0;
        const slider = document.getElementById('mainSlider');
        const dots = document.querySelectorAll('.dot');
        const totalSlides = 3;

        function updateSlider() {
            slider.style.transform = `translateX(-${slideIndex * 100}%)`;
            dots.forEach((dot, i) => dot.classList.toggle('active', i === slideIndex));
        }

        function moveSlide(n) {
            slideIndex = (slideIndex + n + totalSlides) % totalSlides;
            updateSlider();
        }

        // Add click events to dots
        dots.forEach((dot, i) => {
            dot.addEventListener('click', () => {
                slideIndex = i;
                updateSlider();
            });
        });

        // Auto-slide every 6 seconds
        setInterval(() => moveSlide(1), 6000);